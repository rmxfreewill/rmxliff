<?php

	define("HEROKU_HOST", "ble5mmo2o5v9oouq.cbetxkdyhwsb.us-east-1.rds.amazonaws.com");
	define("HEROKU_USER", "qayjkfc2mllng4im");
	define("HEROKU_PASS", "kmfff0oqvbysalq0");
	define("HEROKU_DB", "oxmxf50x8px26gtj");

	define("HOST", "127.0.0.1");
	define("USER", "root");
	define("PASS", "freewill@kernel1168/86-88");
	define("DB", "rmxmain");

	define("PORT", 3306);

	define("POINTID", "10001");
	define("SQLLOG", "1");

	define("CHECKMYSQL", "RMX");
	
	define("URLMYSQL", "/rmxApi");

	define("APIMYSQL", "/rmxApi");
	define("SYNCTIME", "2");	
	define("RMXURLMYSQL", "/rmxApi");
	
	define("RMXHOST", "127.0.0.1");
	define("RMXPORT", 3306);
	define("RMXUSER", "root");
	define("RMXPASS",  "freewill@kernel1168/86-88");
	define("RMXDB", "rmxmain");

	define("BEARER_TOKEN","6DOzScAqBRwD/oRPwvMFua/SBvgLtXciCay4cwK10oTPA88R60mjeGdeW8NDL61dCJX2EtyHINFcj1DvY0mboZntH38a/fhTRI3rCaN4vDI/zWBCl0ze5K/AV2JoxoCwR9OZXj2Y7rHn6nABPwZMVwdB04t89/1O/w1cDnyilFU=");

?>
